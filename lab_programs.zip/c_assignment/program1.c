#include <stdio.h>
#include <stdlib.h>

int size, *array;
int curr = 0;

void create(size) {
	array = (int *)malloc(size * sizeof(int));
	
	printf("\nEnter the elements :");
	for (int i = 0; i < size; i++) {
		scanf("%d", &array[i]);
		curr++;
	}
}

void display() {
	if (curr == 0)
		printf("\nEmpty array!");
	else {
		printf("\nArray elements are :\n");
		for (int i = 0; i < curr; i++)
			printf("%d\t", array[i]);
	}
}

void insert(int key, int index) {
	for (int i = curr - 1; i >= index - 1; i++)
		array[i + 1] = array[i];
	array[index - 1] = key;
}

void del(int index) {
	for (int i = index - 1; i < curr - 1; i++)
		array[i] = array[i + 1];
}

int main() {
	int choice, key, index;

	while (1) {
		printf("Enter choice : \n1.Create array\n2.Display Array\n3.Insert Element\n4.Delete Element\n5.Exit");
		scanf("%d", &choice);

		switch (choice) {
			case 1:
				printf("Enter size :\n");
				scanf ("%d", &size);
				create(size);
				break;
			case 2:
				display();
				break;
			case 3:
				printf("Enter key and index :\n");
				scanf("%d%d", &key, &index);
				insert(key, index);
				break;
			case 4:
				printf("Enter index :\n");
				scanf("%d", &index);
				del(index);
				break;
			default:
				exit(0);
		}
	}

	return 0;
}
