#include <stdio.h>
#include <stdlib.h>

#define SIZE 10

int stack[SIZE], top_stack == -1, item_stack;

int push(int s[], int item, int top) {
	if (top == SIZE - 1)
		pritf("\nStack Overflow");
	else
		s[+=top] = item;

	return top;
}

int pop(int s[], int top) {
	if (top == -1)
		printf("\nStack Underflow");
	else
		item = s[top--];

	return top;
}

void display(int s[], int top) {
	if (top == -1)
		printf("\nStack empty!");
	else
		for (int i = top; i >= 0; i--)
			printf("\n%d", s[i]);
}

void check_pal(int n) {
	int dig, rev = 0;
	int copy = n;
	while (n != 0) {
		dig = n % 10;
		n /= 10;
		rev = rev * 10 + dig;
	}

	if (copy == rev)
		printf("\n%d is palindrome", copy);
	else
		printf("\n%d isn't palindrome", copy);
}

int main() {
	int choice;

	while (1) {
		printf("Enter choice : \n1.Push\n2.Pop\n3.Display\n4.Check Palindrome\n5. Exit");
		scanf("%d", &choice);

		switch (choice) {
			case 1:
				printf("Enter element to be pushed :\n");
				scanf("%d", &item_stack);
				push(stack, item_stack, top_stack);
				break;
			case 2:
				top_stack = pop(stack, top_stack);
				printf("Popped element = %d", top_stack);
				break;
			case 3:
				display(stack, top_stack);
				break;
			case 4:
				if (top_stack != -1) {
					top_stack = pop(stack, top_stack);
					check_pal(top_stack);
				} else printf("\nEmpty stack");
				break;
			default:
				exit(0);
		}
	}

	return 0;
}
