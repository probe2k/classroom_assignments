#include <stdio.h>
#include <stdlib.h>

struct node {
	int c;
	int px;
	struct node *link;
};

typedef struct node *NODE;

void display(NODE head) {
	NODE cur;

	if (head->link == head) {
		printf("Empty polynomial\n");
		return;
	}

	cur = head->link;
	while (cur != head) {
		if (cur->c > 0)
			printf("+%dx^%d ", cur->c, cur->px);
		else
			printf("%dx^%d ", cur->c, cur->px);

		cur = cur->link;
	}

	printf("\n");
}

NODE insert_rear(int c, int px, NODE head) {
	NODE temp, cur;

	cur = head->link;
	while (cur->link != head) {
		cur = cur->link;
	}

	temp = (NODE)malloc(sizeof(struct node));
	temp->c = c;
	temp->px = px;

	cur->link = temp;
	temp->link = head;

	return head;
}

NODE add_poly(NODE head1, NODE head2, NODE head3) {
	NODE cur1, cur2;
	int px, sum;

	cur1 = head1->link;

	while (cur1 != head1) {
		px = cur1->px;

		cur2 = head2->link;
		while (cur2 != head2) {
			if (px == cur2->px) break;
			cur2 = cur2->link;
		}
		if (cur2 == head2) {
			head3 = insert_rear(cur1->c, cur1->px, head3);
		} else {
			sum = cur1->c + cur2->c;
			printf("Sum = %d\n", sum);
			cur2->c = 0;
			if (sum != 0) head3 = insert_rear(sum, cur1->px, head3);
		}

		cur1 = cur1->link;
	}

	cur2 = head2->link;
	while (cur2 != head2) {
		if (cur2->c != 0) head3 = insert_rear(cur2->c, cur2->px, head3);

		cur2 = cur2->link;
	}

	return head3;
}

NODE read_polynomial(NODE head) {
	int n, i, c, px;

	printf("Enter the unumber of terms :");
	scanf("%d", &n);

	for (i = 1; i <= n; i++) {
		printf("Coef: ");
		scanf("%d", &c);
		printf("Power x :");
		scanf("%d", &px);

		head = insert_rear(c, px, head);
	}

	return head;
}

int main() {
	NODE head1, head2, head3;

	head1 = (NODE)malloc(sizeof(struct node));
	head1->link = head1;

	head2 = (NODE)malloc(sizeof(struct node));
	head2->link = head2;

	head3 = (NODE)malloc(sizeof(struct node));
	head3->link = head3;

	printf("Enter the first polynomial\n");
	head1 = read_polynomial(head1);

	printf("Enter the second piolynmial\n");
	head2 = read_polynomial(head2);

	printf("Poly 1:");
	display(head1);

	printf("Poly 2 :");
	display(head2);

	head3 = add_poly(head1, head2, head3);

	printf("Poly 3:");
	display(head3);

	return 0;
}
