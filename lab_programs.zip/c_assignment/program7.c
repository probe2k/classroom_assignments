#include <stdio.h>
#include <stdlib.h>

struct node {
	int usn;
	char name[30];
	char branch[10];
	int sem;
	long int phone;
	struct node *link;
};

typedef struct node *NODE;

NODE insert_front(NODE first) {
	NODE temp;
	temp = (NODE)malloc(sizeof(struct node));
	
	printf("\nEnter USN: \n");
	scanf("%d", &temp -> usn);
	printf("\nEnter name: \n");
	scanf("%s", &temp -> name);
	printf("\nEnter branch: \n");
	scanf("%s", &temp -> branch);
	printf("\nEnter sem: \n");
	scanf("%d", &temp -> sem);
	printf("\nEnter phone: \n");
	scanf("%ld", &temp -> phone);
	temp -> link = first;

	return temp;
}

NODE insert_rear(NODE first) {
	NODE temp, cur;
	temp = (NODE)malloc(sizeof(struct node));

	printf("\nEnter USN: \n");
	scanf("%d", &temp -> usn);
	printf("\nEnter name: \n");
	scanf("%s", &temp -> name);
	printf("\nEnter branch: \n");
	scanf("%s", &temp -> branch);
	printf("\nEnter sem: \n");
	scanf("%d", &temp -> sem);
	printf("\nEnter phone: \n");
	scanf("%ld", &temp -> phone);
	
	cur = first -> link;
	while (cur -> link != NULL)
		cur = cur -> link;

	cur -> link = temp;
	temp -> link = NULL;

	return first;
}

void display(NODE first) {
	NODE temp;

	if (first == NULL) {
		printf("\nList is empty");
		return;
	}

	printf("\nContents are :\n");
	
	temp = first;
	while (temp != NULL) {
		printf("%s\t%d\t%s\t%d\t%ld\n", temp -> name, temp -> usn, temp -> branch, temp -> sem, temp -> phone);
		temp = temp -> link;
	}
}

NODE delete_front(NODE first) {
	NODE temp;

	if (first == NULL) {
		printf("\nList is empty");
		return;
	}

	temp = first;
	temp = temp -> link;
	free(first);
	return temp;
}

NODE delete_rear(NODE first) {
	NODE cur, temp;

	if (first == NULL) {
		printf("\nList is empty");
		return;
	}
	
	if (first -> link == NULL) {
		free(first);
		return NULL;
	}

	cur = first;
	while (cur -> link != NULL) {
		temp = cur;
		cur = cur -> link;
	}

	free(cur);
	temp -> link = NULL;
	return temp;
}

