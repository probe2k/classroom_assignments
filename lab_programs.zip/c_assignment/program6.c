#include <stdio.h>

#define QUEUE_SIZE 6

void enqueue(int queue[], int val, int rear) {
	if (rear == QUEUE_SIZE)
		printf("\nOverflow\n");
	else
		queue[rear++] = val;
}

void dequeue(int queue[], int front, int rear) {
	if (front == QUEUE_SIZE)
		printf("\nUnderflow\n");
	else
		queue[front++] = 0;
}

void display(int queue[], int front, int rear) {
	if (front > rear)
		printf("\nQueue is Empty\n");
	else
		for (int i = 0; i < rear; i++) printf("%d\t", queue[i]);
}

int main() {
	int choice, val;
	int queue[QUEUE_SIZE];
	int front = 0, rear = -1;

	while (1) {
		printf("\n\nMenu\n\n");
		printf("\n1. Insert\n2. Delete\n3. Display\n4. Exit\n");
		scanf("%d", &choice);

		switch (choice) {
			case 1:
				printf("\nEnter the value you want to enqueue :\n");
				scanf("%d", &val);
				enqueue(queue, val, rear);
				break;

			case 2:
				printf("\nDequeueing the queue!\n");
				dequeue(queue, front, rear);
				break;

			case 3:
				printf("\nDisplaying the queue: \n");
				display(queue, front, rear);
				break;

			default:
				exit(0);
		}
	}

	return 0;
}
