#include <math.h>
#include <stdio.h>
#include <string.h>

double compute(char symbol, double op1, double op2) {
	switch (symbol) {
		case '+':
			return op1 + op2;
		case '-':
			return op1 - op2;
		case '*':
			return op1 * op2;
		case '/':
			return op1 / op2;
		case '^':
		case '$':
			return pow(op1, op2);
	}

	return 0;
}

int main() {
	int top, i;
	char symbol;
	char postfix[20];
	double op1, op2, res;
	double s[20];

	printf("Enter postfix expression\n");
	scanf("%s", postfix);

	top = -1;
	
	for (i = 0; i < strlen(postfix); i++) {
		symbol = postfix[i];

		if (symbol >= '0' & symbol <= '9')
			s[++top] = symbol - '0';
		else {
			op2 = s[top--];
			op1 = s[top--];

			res = compute(symbol, op1, op2);
			s[++top] = res;
		}
	}

	res = s[top--];
	printf("Result is %f\n", res);

	return 0;
}



#include <stdio.h>

void toh(int discs, char A, char B, char C) {
	if (discs == 0) {
		printf("Move disc 1 from rod %c to rod %c", A, B);
		return;
	}
	toh(discs, A, C, B);
	printf("Move disc %d from rod %c to rod %c", discs, A, B);
	toh(discs, C, B, A);
}

int main() {
	int n;

	printf("Enter the number of discs present :\n");
	scanf("%d",&n);
	
	toh(discs, 'A', 'C', 'B');

	return 0;
}
